// ==== SUPER AGI: CHAT UI + O‘YINLAR + TOZA INPUT + ENTER VA YUBORISH + ISHLAYDIGAN O‘YINLAR ====

import React, { useState, useRef } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, TouchableOpacity, Image, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import * as Speech from 'expo-speech';
import * as ImagePicker from 'expo-image-picker';

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [profileName, setProfileName] = useState('Foydalanuvchi');
  const [profileImage, setProfileImage] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [memory, setMemory] = useState({});
  const [targetNumber, setTargetNumber] = useState(null);
  const [expectMathAnswer, setExpectMathAnswer] = useState(false);
  const scrollRef = useRef();

  const correctionMap = {
    sallom: 'salom',
    raxmat: 'rahmat',
    kimman: 'isming',
    qalesan: 'qalay',
    yordam: 'yordam',
  };

  const normalizeText = (text) => {
    let fixed = text.toLowerCase();
    Object.keys(correctionMap).forEach(wrong => {
      fixed = fixed.replaceAll(wrong, correctionMap[wrong]);
    });
    return fixed.trim();
  };

  let isOnlineLearning = false;

  const agiReply = async (text) => {
    const clean = normalizeText(text);

    if (expectMathAnswer) {
      setExpectMathAnswer(false);
      if (clean === '5') return '✅ To‘g‘ri javob! 2 + 3 = 5';
      return '❌ Noto‘g‘ri. To‘g‘ri javob 5 edi.';
    }

    if (targetNumber !== null) {
      const guess = parseInt(clean);
      if (!isNaN(guess)) {
        if (guess === targetNumber) {
          setTargetNumber(null);
          return '🎉 To‘g‘ri topdingiz!';
        } else {
          return guess > targetNumber ? '⬇️ Kichikroq son.' : '⬆️ Kattaroq son.';
        }
      }
    }

    if (memory[clean]) return memory[clean];

    const defaultResponses = [
      { key: 'salom', res: 'Salom, sizni ko‘rib hursandman!' },
      { key: 'ism', res: 'Meni ZERO AGI deb atashadi.' },
      { key: 'rahmat', res: 'Doim yordam berishga tayyorman!' },
      { key: 'hayr', res: 'Xayr, salomat bo‘ling!' },
      { key: 'qanday', res: 'Yaxshi, sizchi?' },
      { key: 'qalay', res: 'Yaxshi, sizchi?' },
      { key: 'oyin', res: '🎮 O‘yinlar: 1️⃣ Tic-Tac-Toe, 2️⃣ Son topish, 3️⃣ Quiz, 4️⃣ Rock-Paper-Scissors, 5️⃣ Matematika o‘yini. Qaysi birini tanlaysiz?' },
      { key: 'tic', res: '🔲 Tic-Tac-Toe hali ishlab chiqilmoqda. Tez orada tayyor bo‘ladi.' },
      { key: 'son topish', res: () => { const rand = Math.floor(Math.random() * 10) + 1; setTargetNumber(rand); return `🧠 Son topish o‘yini: 1 dan 10 gacha son o‘yladim. Topa olasizmi?`; } },
      { key: 'quiz', res: '❓ Savol: O‘zbekiston poytaxti qaysi shahar?' },
      { key: 'toshkent', res: '✅ To‘g‘ri! Poytaxt Toshkent!' },
      { key: 'rock', res: '✊✋✌️ Rock-Paper-Scissors o‘yini: Tanlang - rock, paper yoki scissors?' },
      { key: 'matematika', res: () => { setExpectMathAnswer(true); return '➕ Matematika savol: 2 + 3 = ?'; } },
    ];

    for (let pair of defaultResponses) {
      if (clean.includes(pair.key)) {
        const response = typeof pair.res === 'function' ? pair.res() : pair.res;
        return response;
      }
    }

    try {
      const netInfo = await fetch('https://jsonplaceholder.typicode.com/posts/1');
      if (netInfo.ok) {
        isOnlineLearning = true;
        const webData = await netInfo.json();
        const answer = `Bu haqida hozircha javob topilmadi, lekin eslab qoldim.`;
        setMemory(prev => ({ ...prev, [clean]: answer }));
        return answer;
      }
    } catch (e) {}

    const learned = `Bu haqida hali o‘rganmadim, lekin eslab qoldim! (${clean})`;
    setMemory(prev => ({ ...prev, [clean]: learned }));
    return learned;
  };

  const sendMessage = async () => {
    const userText = input.trim();
    if (!userText) return;
    const agiText = await agiReply(userText);
    setMessages(prev => [...prev, { from: 'user', text: userText }, { from: 'agi', text: agiText }]);
    if (isSpeaking) Speech.speak(agiText);
    setInput('');
  };

  const clearMemory = () => {
    Alert.alert('Xotira', 'Suhbatni o‘chirilsinmi?', [
      { text: 'Yo‘q' },
      { text: 'Tozalash', onPress: () => setMessages([]) }
    ]);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync();
    if (!result.canceled) setProfileImage(result.assets[0].uri);
  };

  const colors = {
    bg: darkMode ? '#1a1a1a' : '#f5f5f5',
    text: darkMode ? '#e5e5e5' : '#111',
    input: darkMode ? '#333' : '#ddd',
    userBubble: '#007aff',
    agiBubble: '#444'
  };

  const learningLevel = Object.keys(memory).length;

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
      <View style={[styles.container, { backgroundColor: colors.bg }]}> 
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => setShowSettings(!showSettings)} style={styles.iconBtn}>
            <Text style={styles.iconText}>⚙️</Text>
          </TouchableOpacity>
          <View style={{ flex: 1, alignItems: 'center' }}>
            <Image source={{ uri: 'https://img.icons8.com/3d-fluency/94/artificial-intelligence.png' }} style={{ width: 32, height: 32 }} />
            <Text style={{ color: colors.text, fontWeight: 'bold' }}>ZERO AGI</Text>
          </View>
          <Image
            source={{ uri: profileImage || 'https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png' }}
            style={styles.profileImage}
          />
        </View>

        {showSettings ? (
          <ScrollView>
            <TouchableOpacity onPress={pickImage}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>🖼 Profil rasm tanlash</Text>
            </TouchableOpacity>
            <TextInput
              value={profileName}
              onChangeText={setProfileName}
              style={[styles.input, { backgroundColor: colors.input, color: colors.text }]}
              placeholder="Ismingiz"
              placeholderTextColor="#888"
            />
            <TouchableOpacity onPress={() => setDarkMode(!darkMode)} style={styles.settingBtn}>
              <Text style={styles.btnText}>🌗 Dark Mode</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsSpeaking(!isSpeaking)} style={styles.settingBtn}>
              <Text style={styles.btnText}>{isSpeaking ? '🔊 Ovoz: On' : '🔇 Ovoz: Off'}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={clearMemory} style={styles.settingBtn}>
              <Text style={styles.btnText}>🧹 Xotirani tozalash</Text>
            </TouchableOpacity>
            <View style={{ alignItems: 'center', marginTop: 10 }}>
              <Text style={{ color: colors.text }}>🧠 O‘rganish darajasi: {learningLevel}</Text>
              {isOnlineLearning && <Text style={{ color: 'green', fontSize: 12 }}>🌐 Internetdan o‘rganmoqda</Text>}
            </View>
          </ScrollView>
        ) : (
          <>
            <ScrollView style={styles.chat} ref={scrollRef} keyboardShouldPersistTaps="handled" onContentSizeChange={() => scrollRef.current.scrollToEnd({ animated: true })}>
              {messages.map((msg, i) => (
                <View
                  key={i}
                  style={{
                    alignSelf: msg.from === 'user' ? 'flex-end' : 'flex-start',
                    backgroundColor: msg.from === 'user' ? colors.userBubble : colors.agiBubble,
                    padding: 10,
                    borderRadius: 12,
                    marginVertical: 4,
                    maxWidth: '80%',
                  }}>
                  <Text style={{ color: '#fff' }}>{msg.text}</Text>
                </View>
              ))}
            </ScrollView>
            <View style={styles.inputRow}>
              <TextInput
                value={input}
                onChangeText={setInput}
                onSubmitEditing={sendMessage}
                style={[styles.input, { backgroundColor: colors.input, color: colors.text }]}
                placeholder="Xabar yozing..."
                placeholderTextColor="#999"
                returnKeyType="send"
                blurOnSubmit={false}
              />
              <TouchableOpacity onPress={sendMessage} style={styles.sendBtn}>
                <Text style={styles.sendText}>Yubor</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 20, padding: 10 },
  headerRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5
  },
  iconBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#222', justifyContent: 'center', alignItems: 'center', marginRight: 5, marginTop: 18
  },
  iconText: { fontSize: 20, color: '#fff' },
  profileImage: { width: 40, height: 40, borderRadius: 20, marginTop: 18 },
  chat: { flex: 1 },
  inputRow: { flexDirection: 'row', alignItems: 'center', paddingBottom: 5 },
  input: { flex: 1, padding: 10, borderRadius: 8 },
  sendBtn: { backgroundColor: '#007aff', padding: 10, borderRadius: 8, marginLeft: 10 },
  sendText: { color: '#fff' },
  settingBtn: { backgroundColor: '#333', padding: 10, borderRadius: 8, marginVertical: 5 },
  btnText: { color: '#fff' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginTop: 10 },
});